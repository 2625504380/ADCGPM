% Matlab Model by Jianghua Yin (Mar.,2019,Nanning)
% Copyright (C) 2019 Jian Group
% All Rights Reserved

%% Derivative-Free Projection Method

% NO=1;
% method='PRP+';
 function [Tcpu,NF,Itr,NG] = JLQpk6(NO,method) 
format long
Step=0:4;  % ����һ��5ά��������0,1,2,3,4��
nextstep=Step(1);
% disp(date);
finish=0;
Itr=0;  %% ����
NF=1;   %% Ŀ�꺯���������
%NP=1;  %% ͶӰ�������
tic     %% ��ʼ��ʱ��
while finish==0
    loop=1;
    while loop==1
        switch nextstep
            case Step(1)
                % k=1;
                %% Step 0 ��ʼ�� ��������
                %% ���ó�ʼ��
                [nprob,n,x0]=init(NO);
                epsilon=1e-6;
                epsilon1=1e-8;
                %% ����������
                sigma=0.01; % sigma=0.01
                gamma=0.55;    % gamma=1, initial guess for the steplength
                l=1;
%                 rho=0.4;    % rho=0.9
                %% ��ʼ����
                Fk=feval(nprob,n,x0,1);  % feval��n,x0��ֵ��һ������õĺ���nprob������1��
                dk=(-1)*Fk;
                nextstep=Step(2);
%               tic;
            case Step(2)
                %% Step 1 ��ֹ׼���������
                if norm(Fk,2)<=epsilon || Itr>2000  %����ѭ��
                    %                     disp('��ϲ���������ﵽ����Ҫ��')
                    %                     disp('xk��KKT�㣡��')
                    nextstep=Step(5);  % ����
                    break;
                else  % ������
                 %% Start Armijo-type line search  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    t =gamma;  % initial steplength
                    L1=1;
                    while L1==1
                        z_new=x0+t*dk;
                        Fz_new=feval(nprob,n,z_new,1);
                        NF=NF+1;
                      %   eta_k=(norm(Fz_new,2))/(max(8,norm(Fz_new,2))+min(0.001,norm(Fz_new,2)));  % 0.001,8
                       eta_k1=(norm(Fk,2)^(1-l))/(1+2*max(norm(Fk,2)^(1-l)*(norm(dk,2))^l,norm(Fz_new,2)));  % ��ǿ
%                         eta_k1=norm(Fz_new,2)/(1+2*norm(Fz_new,2));  % ��ǿ
%                         eta_k2=(norm(Fz_new,2)*norm(Fk,2))/(1+3*max(norm(Fz_new,2)*norm(Fk,2),norm(Fz_new,2)));
%                         eta_k=max(eta_k1,eta_k2);
%                            eta_k=norm(Fz_new,2)/(1+8*max(sqrt(norm(Fk,2)^3),norm(Fz_new,2)));  % ��ǿ
                 %       eta_k=norm(Fz_new,2)/(1+(2*norm(Fk,2)));  % ��ǿ
                      %% check the Armijo-type line search condition
                     %   if (-Fz_new'*dk < sigma*t*eta_k*norm(dk,2)^2 && t>10^(-10))  % the Armijo-type line search condition violated
                       if (-Fz_new'*dk < sigma*t*eta_k1*norm(Fz_new,2)*(norm(dk,2))^l && t>10^(-10))  % ��ǿ
                            L1=1;
                            t=0.55*t;
                        else
                            L1=0;
                        end
                    end       % ��ֹwhile L1==1
                 %% End Armijo-type line search %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     t
                    zk=x0+t*dk;  % zk=z_new;
                    Fzk= feval(nprob,n,zk,1);  %  Fzk=Fz_new;
%                     if norm(Fzk,2)<=epsilon
%                        nextstep=Step(5); % ����
%                        break;
%                     else
%                        nextstep=Step(3);
%                     end
                end  % ��ֹ if norm(Fk,2)<=epsilon || Itr>2000  
                nextstep=Step(3);
            case Step(3)
                xik=Fzk'*(x0-zk)/norm(Fzk)^2;
                zk1=x0-1.9*xik*Fzk;     % �˴�ͨ����ͶӰ��ϵ����1
                x1=feval(nprob,n,zk1,2);     % ͶӰ�õ��µĵ�����x_{k+1}
                %NP=NP+1;
                Fk0=Fk;
                Fk=feval(nprob,n,x1,1);   % �����µĺ���ֵF_{k+1}
                NF=NF+1;
                nextstep=Step(4);
            case Step(4)
                %% Step 2 ����
                Itr=Itr+1;
%               Fk0=feval(nprob,n,x0,1);
                sk=x1-x0;
                yk=Fk-Fk0;
                switch method
                  
                        case 'JLQ1'
                       rholl=10;
                       nu=0.4;
                       nv=-50;
                       kk=0.01;
                       nk=norm(Fk,2)/norm(dk,2);
                       betakold=max(2*((Fk'*yk)/(dk'*yk))-(1+((norm(yk,2))^2/(sk'*yk)))*((Fk'*sk)/(dk'*yk)),-50*nk);
                       betak=min(betakold,rholl*nk);
                       if betak*(Fk'*dk)<nu*((norm(Fk,2))^2) && (betak*(Fk'*dk))>nv*((norm(Fk,2))^2)%�޸�2
                       dk=-Fk+betak*dk;
                       else
                       dk=-Fk+kk*((Fk'*yk)/((norm(yk,2))^2))*yk;
                       end
                    case 'JLQ2'
                     rholl=10;
                       nu=0.4;
                       nv=-50;
                       kk=0.01;
                       nk=norm(Fk,2)/norm(dk,2);
                       betakold=max(2*((Fk'*yk)/(dk'*yk))-(1+((norm(yk,2))^2/(sk'*yk)))*((Fk'*sk)/(dk'*yk)),-50*nk);
                       betak=min(betakold,rholl*nk);
                       if betak*(Fk'*dk)<nu*((norm(Fk,2))^2) && (betak*(Fk'*dk))>nv*((norm(Fk,2))^2)%�޸�2
                       dk=-Fk+betak*dk;
                       else
                       dk=-Fk+kk*Fk;
                       end
                   case 'JLQ3'
                      rholl=10;
                       nu=0.4;
                       nv=-50;
                       kk=0.01;
                       nk=norm(Fk,2)/norm(dk,2);
                       betakold=max(2*((Fk'*yk)/(dk'*yk))-(1+((norm(yk,2))^2/(sk'*yk)))*((Fk'*sk)/(dk'*yk)),-50*nk);
                       betak=min(betakold,rholl*nk);
                       if betak*(Fk'*dk)<nu*((norm(Fk,2))^2) && (betak*(Fk'*dk))>nv*((norm(Fk,2))^2)%�޸�2
                       dk=-Fk+betak*dk;
                       else
                      dk=-Fk+kk*((Fk'*Fk0)/(norm(Fk0,2))^2)*Fk0;
                       end
                     case 'JLQ4'
                      rholl=10;
                       nu=0.4;
                       nv=-50;
                       kk=0.01;
                       nk=norm(Fk,2)/norm(dk,2);
                       betakold=max(2*((Fk'*yk)/(dk'*yk))-(1+((norm(yk,2))^2/(sk'*yk)))*((Fk'*sk)/(dk'*yk)),-50*nk);
                       betak=min(betakold,rholl*nk);
                       if betak*(Fk'*dk)<nu*((norm(Fk,2))^2) && (betak*(Fk'*dk))>nv*((norm(Fk,2))^2)%�޸�2
                       dk=-Fk+betak*dk;
                       else
                        dk=-Fk+kk*((Fk'*dk)/(norm(dk,2))^2)*dk;
                       end
                   case 'JLQ5'
                      rholl=10;
                       nu=0.4;
                       nv=-50;
                       kk=0.01;
                       nk=norm(Fk,2)/norm(dk,2);
                       betakold=max(2*((Fk'*yk)/(dk'*yk))-(1+((norm(yk,2))^2/(sk'*yk)))*((Fk'*sk)/(dk'*yk)),-50*nk);
                       betak=min(betakold,rholl*nk);
                       if betak*(Fk'*dk)<nu*((norm(Fk,2))^2) && (betak*(Fk'*dk))>nv*((norm(Fk,2))^2)%�޸�2
                       dk=-Fk+betak*dk;
                       else
                        dk=-Fk+kk*((Fk'*sk)/(norm(sk,2))^2)*sk;
                       end

                end
                x0=x1; 
                if norm(dk)<epsilon1
                    nextstep=Step(5);
                    break;
                end
%                 t=t*(Fk11'*dk0)/(Fk'*dk);
%                 if (Fk'*dk>epsilon1)
%                     x1=x0+t*(-Fk);
%                 end
                nextstep=Step(2);
            case Step(5)
                loop=0;
%                 finish=1;
%                 break;
        end
    end
    if Itr>=2001 %|| norm(gk,2)>epsilon || isnan(Itr)==1  || abs(t)<epsilon  norm(gk,2)>epsilon 
      Tcpu=NaN;
      NF=NaN;
      Itr=NaN;
      NG=NaN;
    else
      Tcpu=toc; 
      NG=norm(Fk);
    end
    finish=1;
%      Tcpu=toc;
end
% [Tcpu Itr NF norm(Fk) norm(dk)]
%Tcpu=cputime-t0;
