% Matlab Model by Jianghua Yin (Dec.,2019,Yulin)
% Copyright (C) 2019 Jian Group
% All Rights Reserved
% Permission to use, copy, modify, and distribute this software and
% its documentation for any purpose and without fee is hereby
% granted, provided that the above copyright notice appear in all
% copies and that the copyright notice and this
% permission notice appear in all supporting documentation.  

% This is a demo of JHYTTCGPM(which respond to the method PRPTTCGPM1-4) method for solving the following constrained
% nonlinear monotone equations
% F(x)=0, x\in C
% where C is a nonempty closed convex set.

% using the algorithm modified three-term conjugate gradient projection method, described in the following paper
%
%  A conjugate gradient projection method with restart procedure for solving constraint equations and image restorations
% -----------------------------------------------------------------------
% Copyright (2019): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 16, 2019
clear all 
clc;
format long
format compact
%% ����latex�����ļ�
fid_tex=fopen('mytext30.txt','w'); 
%% ��ʼ������
%np=168;    %���⼯�ĸ���
np=189 ;    %���⼯�ĸ���
%168+21 = 189
ns=9;     %�㷨�ĸ���
T=zeros(np,ns);F=zeros(np,ns);N=zeros(np,ns); %G=zeros(np,ns);

for i=1:np
  % 1:np
[name,n,a]=init(i);
i
% name=getname(nprob);
% [T1,NFF1,NI1,G1] = line1(i,'ATTCGP');     % acceleration
% [T1,NFF1,NI1,G1] = line1(i,'ATTCGP');     % acceleration
[T1,NFF1,NI1,G1] =JLQpk6(i,'JLQ5');    % acceleration
% [T1,NFF1,NI1,G1] = SMBFGS(i,'SMBFGS');     % acceleration
% [T1,NFF1,NI1,G1] = AHDFPM1(i,'AHDFPM1');     % acceleration
[T2,NFF2,NI2,G2] = JLQpk6(i,'JLQ4');  % Liu J, Feng Y. (2018) PDY, Numerical Algorithms
% [T2,NFF2,NI2,G2] = SGPYJJ(i,'HTTCG');        % Liu J, Feng Y. (2018) PDY, Numerical Algorithms
% [T2,NFF2,NI2,G2] = ISCGP(i,'ISCGP');        % Liu J, Feng Y. (2018) PDY, Numerical Algorithms
%[T2,NFF2,NI2,G2] = SGPYHHM4(i,'PRP+');        % Liu J, Feng Y. (2018) PDY, Numerical Algorithms
[T3,NFF3,NI3,G3] = JLQpk6(i,'JLQ3');      % Sun M., Liu J., (2016) HCGP, Calcolo
% [T4,NFF4,NI4,G4] = SGPYHHM2(i,'PRPTTCGPM2');     % Gao P.T., He C.J., Liu Y., (2019) ATTCGP, Applied Mathematics and Computation
% [T5,NFF5,NI5,G5] = SGPYHHM3(i,'PRPTTCGPM3'); % Sun M., Tian M.Y., (2019)
% [T6,NFF6,NI6,G6] = SGPYHHM4(i,'PRPTTCGPM4');
% [T3,NFF3,NI3,G3] =EIRCGPM(i,'EIRCGPM'); 
% [T3,NFF3,NI3,G3] =AHDFPM1(i,'AHDFPM1'); 
% [T4,NFF4,NI4,G4] =EIRCGPM(i,'EIRCGPM'); 
[T4,NFF4,NI4,G4] = JLQpk6(i,'JLQ2');
[T5,NFF5,NI5,G5] =JLQpk6(i,'JLQ1');
% [T6,NFF6,NI6,G6] = JLJ(i,'JLQ1');
% [T4,NFF4,NI4,G4] = EIRCGPM(i,'EIRCGPM');  
% [T5,NFF5,NI5,G5] = JLQpk6(i,'JLQ1'); 
[T6,NFF6,NI6,G6] = JLQqk6(i,'JLQ5');
[T7,NFF7,NI7,G7] = JLQqk6(i,'JLQ4');  
[T8,NFF8,NI8,G8] = JLQqk6(i,'JLQ3'); 
[T9,NFF9,NI9,G9] = JLQqk6(i,'JLQ1');  
% [T10,NFF10,NI10,G10] =JLQqk6(i,'JLQ5'); 
T(i,:) = [T1,T2,T3,T4,T5,T6,T7,T8,T9];
F(i,:) = [NFF1,NFF2,NFF3,NFF4,NFF5,NFF6,NFF7,NFF8,NFF9];
N(i,:) = [NI1,NI2,NI3,NI4,NI5,NI6,NI7,NI8,NI9];
% G(i,:) = [G1,G2,G3,G4]; %,G5];
b=n/10000;
%% ���뵽 latex 
fprintf(fid_tex,'%s $x_{%d}(%d)$ &%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e \\\n',...
                name,b,b,NI1,NFF1,T1,G1,NI2,NFF2,T2,G2,NI3,NFF3,T3,G3,NI4,NFF4,T4,G4,NI5,NFF5,T5,G5,NI6,NFF6,T6,G6,NI7,NFF7,T7,G7,NI8,NFF8,T8,G8,NI9,NFF9,T9,G9);
end
%% �ر��ļ�
fclose(fid_tex);

%% ��ͼ
clf;   %clfɾ����ǰͼ�δ����С�
       %%���δ������(�����ǵ�HandleVisibility����Ϊon)��ͼ�ζ���
figure(1);
%subplot(2,2,1);
perf(T,'logplot');
%title('ʱ������');
%set(gca,'ylim',[0.3,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
% legend('ATTCGP' ,'HTTCG','JHYTTCGPM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('AHDFPM' ,'HTTCG','JFM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('ATTCGP' ,'HTTCGP','AHDFPM','JLQ1','JLQ2','JLQ3','JLQ4');
legend('JLJ :qk=F_k  pk=s_k_-_1' ,'JLJ :qk=F_k  pk=d_k_-_1','JLJ :qk=F_k  pk=F_k_-_1','JLJ :qk=F_k   pk=F_k','JLJ :qk=F_k  pk=y_k_-_1','JLJ :qk=s_k_-_1  pk=y_k_-_1' ,'JLJ :qk=d_k_-_1  pk=y_k_-_1','JLJ :qk=F_k_-_1  pk=y_k_-_1','JLJ :qk=y_k_-_1   pk=y_k_-_1');
h= findobj(gca, 'Type', 'line');
% ��ת���˳����Ϊ�����Ƶ����ھ�������ǰ��
h = h(end:-1:1);
% ����ǰ5����Ϊ���ߣ���5����Ϊʵ��
for i = 1:5
    set(h(i), 'LineStyle', '-');
end
for i = 6:9
    set(h(i), 'LineStyle', '--');
end
%subplot(2,2,2);
figure(2);
perf(F,'logplot');
%title('Ŀ�꺯����������');
% set(gca,'ylim',[0.1,1]);
xlabel('\tau','Interpreter','tex');                 
ylabel('\rho(\tau)','Interpreter','tex');            
% legend('ATTCGP' ,'HTTCG','JHYTTCGPM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('AHDFPM' ,'HTTCG','JFM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('ATTCGP' ,'HTTCGP','AHDFPM','JLQ1','JLQ2','JLQ3','JLQ4');
legend('JLJ :qk=F_k  pk=s_k_-_1' ,'JLJ :qk=F_k  pk=d_k_-_1','JLJ :qk=F_k  pk=F_k_-_1','JLJ :qk=F_k   pk=F_k','JLJ :qk=F_k  pk=y_k_-_1','JLJ :qk=s_k_-_1  pk=y_k_-_1' ,'JLJ :qk=d_k_-_1  pk=y_k_-_1','JLJ :qk=F_k_-_1  pk=y_k_-_1','JLJ :qk=y_k_-_1   pk=y_k_-_1');
h= findobj(gca, 'Type', 'line');
% ��ת���˳����Ϊ�����Ƶ����ھ�������ǰ��
h = h(end:-1:1);
% ����ǰ5����Ϊ���ߣ���5����Ϊʵ��
for i = 1:5
    set(h(i), 'LineStyle', '-');
end
for i = 6:9
    set(h(i), 'LineStyle', '--');
end
%subplot(2,2,3);
figure(3);
perf(N,'logplot');
%title('������������');
%set(gca,'ylim',[0.5,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
% legend('ATTCGP' ,'HTTCG','JHYTTCGPM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('AHDFPM' ,'HTTCG','JFM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('ATTCGP' ,'HTTCGP','AHDFPM','JLQ1','JLQ2','JLQ3','JLQ4');
legend('JLJ :qk=F_k  pk=s_k_-_1' ,'JLJ :qk=F_k  pk=d_k_-_1','JLJ :qk=F_k  pk=F_k_-_1','JLJ :qk=F_k   pk=F_k','JLJ :qk=F_k  pk=y_k_-_1','JLJ :qk=s_k_-_1  pk=y_k_-_1' ,'JLJ :qk=d_k_-_1  pk=y_k_-_1','JLJ :qk=F_k_-_1  pk=y_k_-_1','JLJ :qk=y_k_-_1   pk=y_k_-_1');
h= findobj(gca, 'Type', 'line');
% ��ת���˳����Ϊ�����Ƶ����ھ�������ǰ��
h = h(end:-1:1);
% ����ǰ5����Ϊ���ߣ���5����Ϊʵ��
for i = 1:5
    set(h(i), 'LineStyle', '-');
end
for i = 6:9
    set(h(i), 'LineStyle', '--');
end


