% Matlab Model by Jianghua Yin (Dec.,2019,Yulin)
% Copyright (C) 2019 Jian Group
% All Rights Reserved
% Permission to use, copy, modify, and distribute this software and
% its documentation for any purpose and without fee is hereby
% granted, provided that the above copyright notice appear in all
% copies and that the copyright notice and this
% permission notice appear in all supporting documentation.  

% This is a demo of JHYTTCGPM(which respond to the method PRPTTCGPM1-4) method for solving the following constrained
% nonlinear monotone equations
% F(x)=0, x\in C
% where C is a nonempty closed convex set.

% using the algorithm modified three-term conjugate gradient projection method, described in the following paper
%
%  A conjugate gradient projection method with restart procedure for solving constraint equations and image restorations
% -----------------------------------------------------------------------
% Copyright (2019): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 16, 2019
clear all 
clc;
format long
format compact
%% ����latex�����ļ�
fid_tex=fopen('mytext2.txt','w'); 
%% ��ʼ������
%np=168;    %���⼯�ĸ���
np=189 ;    %���⼯�ĸ���
%168+21 = 189
ns=8;     %�㷨�ĸ���
T=zeros(np,ns);F=zeros(np,ns);N=zeros(np,ns); %G=zeros(np,ns);


for i=1:np
  % 1:np
[name,n,a]=init(i);
i
[T1,NFF1,NI1,G1] =JLJL6(i,'JLQ5');    % acceleration
[T2,NFF2,NI2,G2] = JLJL7(i,'JLQ5');  % Liu J, Feng Y. (2018) PDY, Numerical Algorithms
[T3,NFF3,NI3,G3] = JLJL8(i,'JLQ5');      % Sun M., Liu J., (2016) HCGP, Calcolo
[T4,NFF4,NI4,G4] = JLJL9(i,'JLQ5'); 
[T5,NFF5,NI5,G5] =JLJL1(i,'JLQ5'); 
[T6,NFF6,NI6,G6] = JLJL2(i,'JLQ5'); 
[T7,NFF7,NI7,G7] = JLJL3(i,'JLQ5');  
[T8,NFF8,NI8,G8] = JLJL4(i,'JLQ5'); 
T(i,:) = [T1,T2,T3,T4,T5,T6,T7,T8];
F(i,:) = [NFF1,NFF2,NFF3,NFF4,NFF5,NFF6,NFF7,NFF8];
N(i,:) = [NI1,NI2,NI3,NI4,NI5,NI6,NI7,NI8];
% G(i,:) = [G1,G2,G3,G4]; %,G5];
b=n/10000;
%% ���뵽 latex 
fprintf(fid_tex,'%s $x_{%d}(%d)$ &%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e \\\n',...
                name,b,b,NI1,NFF1,T1,G1,NI2,NFF2,T2,G2,NI3,NFF3,T3,G3,NI4,NFF4,T4,G4,NI5,NFF5,T5,G5,NI6,NFF6,T6,G6,NI7,NFF7,T7,G7,NI8,NFF8,T8,G8);
end
%% �ر��ļ�
fclose(fid_tex);

%% ��ͼ
clf;   %clfɾ����ǰͼ�δ����С�
       %%���δ������(�����ǵ�HandleVisibility����Ϊon)��ͼ�ζ���
figure(1);
%subplot(2,2,1);
perf(T,'logplot');
%title('ʱ������');
%set(gca,'ylim',[0.3,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
% legend('ATTCGP' ,'HTTCG','JHYTTCGPM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('AHDFPM' ,'HTTCG','JFM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('ATTCGP' ,'HTTCGP','AHDFPM','JLQ1','JLQ2','JLQ3','JLQ4');
legend('JLJ-UDF: l=0.5' ,'JLJ-UDF: l=1','JLJ-UDF: l=2','JLJ-UDF: l=3','JLJ: l=0.5' ,'JLJ: l=1','JLJ: l=2','JLJ: l=3');
%subplot(2,2,2);
figure(2);
perf(F,'logplot');
%title('Ŀ�꺯����������');
% set(gca,'ylim',[0.1,1]);
xlabel('\tau','Interpreter','tex');                 
ylabel('\rho(\tau)','Interpreter','tex');            
% legend('ATTCGP' ,'HTTCG','JHYTTCGPM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('AHDFPM' ,'HTTCG','JFM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('ATTCGP' ,'HTTCGP','AHDFPM','JLQ1','JLQ2','JLQ3','JLQ4');
legend('JLJ-UDF: l=0.5' ,'JLJ-UDF: l=1','JLJ-UDF: l=2','JLJ-UDF: l=3','JLJ: l=0.5' ,'JLJ: l=1','JLJ: l=2','JLJ: l=3');

%subplot(2,2,3);
figure(3);
perf(N,'logplot');
%title('������������');
%set(gca,'ylim',[0.5,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
% legend('ATTCGP' ,'HTTCG','JHYTTCGPM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('AHDFPM' ,'HTTCG','JFM','JLQ1','JLQ2','JLQ3','JLQ4');
% legend('ATTCGP' ,'HTTCGP','AHDFPM','JLQ1','JLQ2','JLQ3','JLQ4');
legend('JLJ-UDF: l=0.5' ,'JLJ-UDF: l=1','JLJ-UDF: l=2','JLJ-UDF: l=3','JLJ: l=0.5' ,'JLJ: l=1','JLJ: l=2','JLJ: l=3');



